# js-tetris

Tetris game in Modern JavaScript.

![tetris picture](assets/share-image-large.png)
